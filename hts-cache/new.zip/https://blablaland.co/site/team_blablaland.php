﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="fr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
	<meta content="Blablaland est un jeu de tchat gratuit pour ados, d&#x00E9;lires avec tes potes dans un monde virtuel fun et color&#x00E9;" name="description">
	<meta content="tchat, jeu tchat, chat gratuit, tchat ado, jeu virtuel, ados, tchat, blablaland, clavardage, clavarder" name="keywords">
	<title>Blablaland Tchat gratuit, jeu virtuel et tchat pour ados</title>
	<link rel="SHORTCUT ICON" href="/favicon.ico">
	<link rel="icon" type="image/x-icon" href="/favicon.ico">
	<script src="/assets/js/jquery/jquery-1.12.4.min.js"></script>
	<script src="/assets/js/SwfObject.js"></script>
	<script src="/assets/js/jq_functions.js"></script>
	<script>
	   bblinfos_nbmess_new = bblinfos_nbmess_tot = 0;
	</script>
	<link href="/assets/css/html5.css" rel="stylesheet">
	<link href="/data/backgr/css/vers2/_base.css" rel="stylesheet">
		<link href="/data/backgr/css/forum/Oxygen.css" rel="stylesheet">
	<link rel="stylesheet" href="/data/backgr/css/site.css">	<style>
		  .bloc_droit_bg {
			  -webkit-border-radius: 10px;
			  -moz-border-radius: 10px;
			  border-radius: 10px;
			  background:#64c5fc;
			  padding:0 3px 10px 4px;
		  }
	.ab7{ color: #f50085;    background-color: #FFFFFF;    text-shadow: none;}td{padding:0}
	.calawc{line-height: 16px; margin-bottom: 5px;}	</style>
		</head>
<body>
	<div class=" fb_reset" id="fb-root">
		<div style="position: absolute; top: -10000px; height: 0px; width: 0px;">
			<div></div>
		</div>
		<div style="position: absolute; top: -10000px; height: 0px; width: 0px;">
			<div></div>
		</div>
	</div>
		<div id="N99_BAR">
		<div id="N99_BAR_CONT">
			<a href="/site/shop_index.php" target="_blank" title="Boutique Blablaland">BOUTIQUE</a> <a href="/site/team_blablaland.php" target="_blank" title="Obtenez de l&#39;aide sur nos services">ASSISTANCE</a> <a class="N99_BAR_ACTIVE" href="/" target="_blank" title="Jouer &#x00E9; Blablaland">BLABLALAND</a>
		</div>
		<div id="HEADER_INFOS_JEU">
			<strong>37 999</strong> joueurs | <strong>4</strong> en ligne
		</div>
	</div>
	<div id="DECO">
		<div id="MAIN">

						<div id="HEADER">
				<div id="HEADER_LOGO_BLABLALAND">
					<a href="/" title="Blablaland, jeu vid&#x00E9;o en ligne : l&#39;aventure commence ici"><img style="width: 100%; height: 100%;" alt="Blablaland, le jeu vid&#x00E9;o en ligne multijoueur : 1&#39;Aventure commence ici !!" src="/data/logo/1logo_blablaland_topsite.png"></a>
				</div>
				<div id="HEADER_INFOS">
					
										<div id="HEADER_PROFIL" style="padding-top: 8px;">
						<div id="MY_AVATAR"><img alt="" src="/data/Profil/tmp_profil.png"></div>
						<div id="PROFIL_LOGIN_BOX">
							<form action="/site/connexion.php" method="post">
								<input class="login_box_input" id="con_pseudo" name="con_pseudo" onfocus="javascript:if(this.value == 'Login') {this.value='';this.style.color='#666666';}" tabindex="1" type="text" value="Login"> <input class="login_box_input" id="con_password" name="con_password" style="color: rgb(102, 102, 102);" tabindex="2" type="password" value=""> <input name="con_page" type="hidden" value="/"> <a class="btn_lost_ident" href="/site/mot_de_passe_perdu.php" tabindex="4">Identifiants perdus ?</a> <input class="login_box_ok" id="validform" name="validform" tabindex="3" type="submit" value="OK">
							</form>
						</div>
					</div>
									</div>
			</div>
			
			<a></a>

						<div id="MENU">
				<ul>
					<li class="menu_btn_home">
						<a href="/" title="Accueil du site"><img alt="" src="/data/backgr/deco/_home.png"></a>
					</li>
					<li>
						<a href="/site/blablaland.php"><span class="ab1">Le Jeu</span></a>
						<ul>
							<li>
								<a href="/site/blablaland.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/blablaland.png">D&#x00E9;couvrez le jeu
								<div>
									L'aventure commence ici ! Partez à la d&#x00E9;couverte du jeu vid&#x00E9;o Blablaland.
								</div></a>
							</li>
							<li>
								<a href="/site/news.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/blablaland_news.png">L'actualit&#x00E9; du jeu
								<div>
									Toutes les derni&#x00E9;res nouveaut&#x00E9;s et mises à jour à d&#x00E9;couvrir !
								</div></a>
							</li>
						</ul>
					</li>
					<li>
						<a href="/site/communaute.php"><span class="ab2">Communaut&#x00E9;</span></a>
						<ul>
							<li>
								<a href="/site/bblartclub.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/communaute_artclub.png">BBL Art'Club (FanArt)
								<div>
									D&#x00E9;couvrez les meilleurs dessins, vid&#x00E9;os et autres d&#x00E9;lires des joueurs.
								</div></a>
							</li>
							<li>
								<a href="/site/fansites.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/communaute_fansite.png">FanSites
								<div>
									Prolongez l'aventure Blablaland avec les sites web cr&#x00E9;es par des joueurs.
								</div></a>
							</li>
							<li>
								<a href="/site/annuaire_bbl.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/communaute_annuaire.png">Annuaire des joueurs
								<div>
									Partez à la d&#x00E9;couverte des milliers d'autres joueurs de Blablaland !
								</div></a>
							</li>
							<li class="menu_getmore">
								<a href="/site/communaute.php">Toute la communaut&#x00E9; !</a>
							</li>
						</ul>
					</li>
					<li>
						<a   href="/forum"><span class="ab3">Forum</span></a>
					</li>
					<li>
						<a href="/site/mini_jeux.php"><span class="ab5">Mini-Jeux</span></a>
						<ul>
							<li>
								<a href="/site/jeu_donjon.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/jeu_donjon.png">Donjon
								<div>
									Combattez les monstres entre amis !
								</div></a>
							</li>
							<li>
								<a href="/site/jeu_manoir.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/jeu_manoir.png">Manoir Hant&#x00E9;
								<div>
									Lancez-vous dans le chariot de la mort du Manoir Hant&#x00E9;... d&#x00E9;lires &amp; frissons garantis !
								</div></a>
							</li>
							<li>
								<a href="/site/jeu_pyramide.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/jeu_pyramide.png">Pyramide Huybit III
								<div>
									Affrontez la mal&#x00E9;diction de la Pyramide pour retrouver le sarcophage secret !
								</div></a>
							</li>
							<li>
								<a href="/site/jeu_bbl_tournament_fury.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/jeu_bbltf.png">Tournament Fury
								<div>
									Rejoignez la Bataille, prennez les armes et devenez le prochain H&#x00E9;ros.
								</div></a>
							</li>
							<li>
								<a href="/site/jeu_blablataille_navale.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/jeu_bblnavale.png">Blablataille Navale
								<div>
									Affrontez les autres joueurs à la Blablataille Navale !
								</div></a>
							</li>
							<li class="menu_getmore">
								<a href="/site/mini_jeux.php">Tous les Mini-Jeux !</a>
							</li>
						</ul>
					</li>
					<li>
						<a href="/site/goodies.php"><span class="ab6">M&#x00E9;dias</span></a>
						<ul>
							<li>
								<a href="/site/bd_blabla.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/bd_blablaland.png">BD Blabla
								<div>
									Passez d'excellents moments de d&#x00E9;lire en lisant les BD.
								</div></a>
							</li>
							<li>
								<a href="/site/goodies.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/goodies.png">Goodies
								<div>
									Wallpapers, Vid&#x00E9;os &amp; autres Goodies pour poursuivre l'aventure !!
								</div></a>
							</li>
						</ul>
					</li>
					<li class="menu_btn_jouer">
						<a href="/chat/bbl_chat.php"><span>JOUER</span></a>
					</li>
					<li>
						<a href="/site/shop_index.php"><span class="ab4">Boutique</span></a>
						<ul>
							<li>
								<a href="/site/shop_index.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/shop_boutique.png">Boutique
								<div>
									Skins, Objets, Pouvoirs, Smileys, Montures, Bliblis... tout est là pour booster ton perso :)
								</div></a>
							</li>
						</ul>
					</li>
					<li>
						<a href="/site/aide.php"><span class="ab7">Aide</span></a>
						<ul>
							<li>
								<a href="/site/infos_reglement.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/aide.png">Réglement
								<div>
									Consulter le réglement de Blablaland
								</div></a>
							</li>
							<li>
								<a href="/site/moderateurs.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/moderateurs.png">Mod&#x00E9;ration
								<div>
									En savoir plus sur la mod&#x00E9;ration de Blablaland
								</div></a>
							</li>
							<li>
								<a href="/site/team_blablaland.php"><img alt="" class="menu_ico" src="/data/backgr/old/menu/team_blabla.png">Team Blablaland.co
								<div>
									Les mod&#x00E9;rateurs, les animateurs, l'&#x00E9;quipe Blablaland.co !!
								</div></a>
							</li>
						</ul>
					</li>
									</ul>
				<div id="MENU_BTN_CTA">
					<a href="/site/inscription.php"><img alt="" src="/data/singup/tmp_smiley.png">S'INSCRIRE</a> 				</div>
			</div>
    
			<div id="PAGE" style="min-height:0;">

								<div style="padding-top:10px;"></div>
				</div>	<div id="BBLOLD_LEFT">
		<table class="color_bg_vert td0" style="width:750px;border-spacing:0;">
			<tbody>
				<tr>
					<td class="corner_TL"><img src="/data/left/corner_TL.gif" alt style="width:10px;height:10px"></td>
					<td style="height:15px;width:730px">&nbsp;&nbsp;&nbsp;<span class="box_title">On est là :)</span></td>
					<td class="corner_TR"><img src="/data/left/corner_TR.gif" alt style="width:10px;height:10px"></td>
				</tr>
				<tr>
					<td colspan="3" style="vertical-align:top;width:750px">
						<table class="color_bg_white" style="border-spacing:2px;width:100%">
							<tbody>
								<tr>
									<td class="box_vert td0" style="vertical-align:top">
										<table class="td5" style="border-spacing:0;width:100%">
											<tbody>
												<tr>
													<td id="DIVP_BBL">
														<div id="DIVP_BBL_1"></div>
														<script src="/assets/js/swf/big_title.js#L'EQUIPE%20BLABLALAND"></script>
													</td>
												</tr>
												<tr>
													<td style="vertical-align:top">
														<table class="td0" style="border-spacing:0;width:100%">
															<tbody>
																<tr>
																	<td style="text-align:center;vertical-align:top;width:180px">
																		<div id="div_swf_faq">
																			<canvas id="faq_gandalf" width="150" height="190"></canvas>
																		</div>
																		<script src="/assets/js/swf/faq_gandalf.js"></script>
																	</td>
																	<td style="vertical-align:top">
																		<br>
																		<table class="td0" style="border-spacing:0;width:100%">
																			<tbody>
																				<tr>
																					<td style="width:20px;height:10px;line-height:0"><img src="/data/left/TLA.gif" alt style="width:20px;height:10px"></td>
																					<td style="width:9px;height:10px;line-height:0"><img src="/data/left/TLB.gif" alt style="width:9px;height:10px"></td>
																					<td style="height:10px;background:url(/data/left/TM.gif);background-size:contain;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:100%;height:10px"></td>
																					<td style="width:15px;height:10px;line-height:0"><img src="/data/left/TR.gif" alt style="width:15px;height:10px"></td>
																				</tr>
																				<tr>
																					<td style="vertical-align:top;width:20px;background:url(/data/left/MLA.gif)"><img src="/data/left/spacer.gif" alt width="20" height="40" style="float:left"><img src="/data/left/talk.gif" alt style="width:20px;height:25px"></td>
																					<td style="background:#FFFFFF;width:9px">&nbsp;</td>
																					<td style="background:#FFFFFF;vertical-align:top"> <span class="txt_14b">Toute l'équipe de Blablaland</span>
																						<br>
																						<br> Blablaland évolue chaque jour un peu plus grâce à vous mais aussi grâce à toutes celles et ceux qui l'aident à devenir meilleur.
																						<br>
																						<br> <strong>Tu trouveras ci-dessous la liste officielle de la team Blablaland !</strong>
																						<br>
																						<br> <span style="color:#FF6666;"><strong>Note :</strong> Ceux qui disent appartenir à l'équipe et qui ne sont pas listés sur cette page sont des arnaqueurs. On ne devient pas modérateur en échange de son mot de passe, de codes sms ou de son compte blabla ;)</span>
																						<br>
																						<br>
																						<br>
																					</td>
																					<td style="width:15px;background:url(/data/left/MR.gif)">&nbsp;</td>
																				</tr>
																				<tr>
																					<td style="height:15px;width:20px;line-height:0"><img src="/data/left/BLA.gif" alt style="width:20px;height:15px"></td>
																					<td style="height:15px;width:9px;line-height:0"><img src="/data/left/BLB.gif" alt style="width:9px;height:15px"></td>
																					<td style="height:15px;line-height:0;background:url(/data/left/BM.gif)"><img src="/data/left/spacer.gif" alt style="width:100%;height:15px"></td>
																					<td style="height:15px;width:15px;line-height:0"><img src="/data/left/BR.gif" alt style="width:15px;height:15px"></td>
																				</tr>
																			</tbody>
																		</table>
																	</td>
																</tr>
															</tbody>
														</table>
														<br><br>
														<a id="list_modos"></a>
														<div id="DIVG_BBL_1"></div>
														<script src="/assets/js/swf/goodies_title.js"></script>
														<script>
														goodies("DIVG_BBL_1", "LES MODERATEURS ET ANIMATEURS");
														</script>
														<br>
														<table class="td0" style="background:#FFF6BC;border-spacing:0;width:100%">
															<tbody>
																<tr>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_tl.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																	<td class="boxjaune_brd_t" style="height:10px;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_tr.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																</tr>
																<tr>
																	<td class="boxjaune_brd_l" style="width:10px"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																	<td> Ce sont des personnes bénévoles qui connaissent très bien Blablaland et qui interviennent sur le jeu et sur le Forum pour s’assurer que <a href="/site/infos_reglement.php" target="_blank">le Règlement de Blablaland</a> est bien respecté et que chacun peut jouer, s’amuser, discuter dans une ambiance agréable et fun. Les modérateurs peuvent envoyer des Messages Privés, kicker du jeu ou bien mettre en prison.
																		<br>
																		<br>
																		<a class="fofo_link3_extern" href="/site/moderateurs.php">Pour en savoir plus sur le rôle des Modérateurs, clique ici.</a>
																																			</td>
																	<td class="boxjaune_brd_r" style="width:10px"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																</tr>
																<tr>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_dl.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																	<td class="boxjaune_brd_b" style="height:10px;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_dr.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																</tr>
															</tbody>
														</table>
														<br>
																												<br><br><br>
														<table class="td0" style="width:100%;border-spacing:0;background:#fff6bc">
															<tbody>
																<tr>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_tl.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td class="boxjaune_brd_t" style="height:10px;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_tr.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																</tr>
																<tr>
																	<td class="boxjaune_brd_l" style="width:10px"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td>
																		<span style="color:#000000;"><strong style="font-size:13px;">Les Modérateurs</strong></span>
																	</td>
																	<td class="boxjaune_brd_r" style="width:10px"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																</tr>
																<tr>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_dl.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td class="boxjaune_brd_b" style="height:10px;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_dr.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																</tr>
															</tbody>
														</table><br>
																												<div style="text-align:center">
															<center>
																<div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_38431" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=226981&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_38431= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_38431.addParam("wmode", "transparent");swf_showSkin_38431.addVariable("ACTION", "40");
																		swf_showSkin_38431.addVariable("SKINID", "");
																		swf_showSkin_38431.addVariable("SKINCOLOR", "");
																		swf_showSkin_38431.addVariable("FONDID", "0");
																		swf_showSkin_38431.addVariable("SHOWSKIN", "0");
																		swf_showSkin_38431.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_38431.addVariable("CLICKURL", "membres.php?p=38431");
																		swf_showSkin_38431.addVariable("HIDEBORDER", "1");

																		swf_showSkin_38431.addParam("menu", "true");
																		swf_showSkin_38431.write("div_showSkin_38431");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=38431">
																			<strong>Acy</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_36806" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=848359&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_36806= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "5", "#FFFFFF");
																		swf_showSkin_36806.addParam("wmode", "transparent");swf_showSkin_36806.addVariable("ACTION", "50");
																		swf_showSkin_36806.addVariable("SKINID", "5");
																		swf_showSkin_36806.addVariable("SKINCOLOR", "K0%0B%0B0%0B%0B%01%01%01");
																		swf_showSkin_36806.addVariable("FONDID", "0");
																		swf_showSkin_36806.addVariable("SHOWSKIN", "1");
																		swf_showSkin_36806.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_36806.addVariable("CLICKURL", "membres.php?p=36806");
																		swf_showSkin_36806.addVariable("HIDEBORDER", "1");

																		swf_showSkin_36806.addParam("menu", "true");
																		swf_showSkin_36806.write("div_showSkin_36806");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=36806">
																			<strong>Enty</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_36800" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=204412&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_36800= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_36800.addParam("wmode", "transparent");swf_showSkin_36800.addVariable("ACTION", "0");
																		swf_showSkin_36800.addVariable("SKINID", "");
																		swf_showSkin_36800.addVariable("SKINCOLOR", "");
																		swf_showSkin_36800.addVariable("FONDID", "0");
																		swf_showSkin_36800.addVariable("SHOWSKIN", "0");
																		swf_showSkin_36800.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_36800.addVariable("CLICKURL", "membres.php?p=36800");
																		swf_showSkin_36800.addVariable("HIDEBORDER", "1");

																		swf_showSkin_36800.addParam("menu", "true");
																		swf_showSkin_36800.write("div_showSkin_36800");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=36800">
																			<strong>Fataliste</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_42417" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=673299&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_42417= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_42417.addParam("wmode", "transparent");swf_showSkin_42417.addVariable("ACTION", "10");
																		swf_showSkin_42417.addVariable("SKINID", "");
																		swf_showSkin_42417.addVariable("SKINCOLOR", "");
																		swf_showSkin_42417.addVariable("FONDID", "0");
																		swf_showSkin_42417.addVariable("SHOWSKIN", "0");
																		swf_showSkin_42417.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_42417.addVariable("CLICKURL", "membres.php?p=42417");
																		swf_showSkin_42417.addVariable("HIDEBORDER", "1");

																		swf_showSkin_42417.addParam("menu", "true");
																		swf_showSkin_42417.write("div_showSkin_42417");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=42417">
																			<strong>Meridian</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_39969" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=154916&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_39969= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FCC4FE");
																		swf_showSkin_39969.addParam("wmode", "transparent");swf_showSkin_39969.addVariable("ACTION", "0");
																		swf_showSkin_39969.addVariable("SKINID", "");
																		swf_showSkin_39969.addVariable("SKINCOLOR", "");
																		swf_showSkin_39969.addVariable("FONDID", "0");
																		swf_showSkin_39969.addVariable("SHOWSKIN", "0");
																		swf_showSkin_39969.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_39969.addVariable("CLICKURL", "membres.php?p=39969");
																		swf_showSkin_39969.addVariable("HIDEBORDER", "1");

																		swf_showSkin_39969.addParam("menu", "true");
																		swf_showSkin_39969.write("div_showSkin_39969");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=39969">
																			<strong>ninelli</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_38417" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=68446&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_38417= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_38417.addParam("wmode", "transparent");swf_showSkin_38417.addVariable("ACTION", "0");
																		swf_showSkin_38417.addVariable("SKINID", "");
																		swf_showSkin_38417.addVariable("SKINCOLOR", "");
																		swf_showSkin_38417.addVariable("FONDID", "0");
																		swf_showSkin_38417.addVariable("SHOWSKIN", "0");
																		swf_showSkin_38417.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_38417.addVariable("CLICKURL", "membres.php?p=38417");
																		swf_showSkin_38417.addVariable("HIDEBORDER", "1");

																		swf_showSkin_38417.addParam("menu", "true");
																		swf_showSkin_38417.write("div_showSkin_38417");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=38417">
																			<strong>Yas</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Modo de l'année <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_43618" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background: #FFFFFF"></div>
																		<script type="text/javascript">
																		var swf_showSkin_43618= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "299", "#FFFFFF");
																		swf_showSkin_43618.addParam("wmode", "transparent");swf_showSkin_43618.addVariable("ACTION", "0");
																		swf_showSkin_43618.addVariable("SKINID", "299");
																		swf_showSkin_43618.addVariable("SKINCOLOR", "%27%0B%3C%27%3C%27%3B-%14-");
																		swf_showSkin_43618.addVariable("FONDID", "0");
																		swf_showSkin_43618.addVariable("SHOWSKIN", "1");
																		swf_showSkin_43618.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_43618.addVariable("CLICKURL", "membres.php?p=43618");
																		swf_showSkin_43618.addVariable("HIDEBORDER", "1");

																		swf_showSkin_43618.addParam("menu", "true");
																		swf_showSkin_43618.write("div_showSkin_43618");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=43618">
																			<strong>Brrrr</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				P'tit Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_42567" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=303103&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_42567= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_42567.addParam("wmode", "transparent");swf_showSkin_42567.addVariable("ACTION", "0");
																		swf_showSkin_42567.addVariable("SKINID", "");
																		swf_showSkin_42567.addVariable("SKINCOLOR", "");
																		swf_showSkin_42567.addVariable("FONDID", "0");
																		swf_showSkin_42567.addVariable("SHOWSKIN", "0");
																		swf_showSkin_42567.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_42567.addVariable("CLICKURL", "membres.php?p=42567");
																		swf_showSkin_42567.addVariable("HIDEBORDER", "1");

																		swf_showSkin_42567.addParam("menu", "true");
																		swf_showSkin_42567.write("div_showSkin_42567");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=42567">
																			<strong>Homura</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				P'tit Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_420" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background: #FFFFFF"></div>
																		<script type="text/javascript">
																		var swf_showSkin_420= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "7", "#FFFFFF");
																		swf_showSkin_420.addParam("wmode", "transparent");swf_showSkin_420.addVariable("ACTION", "0");
																		swf_showSkin_420.addVariable("SKINID", "7");
																		swf_showSkin_420.addVariable("SKINCOLOR", "%149%0B%0B%10%0C%01%01%01%01");
																		swf_showSkin_420.addVariable("FONDID", "0");
																		swf_showSkin_420.addVariable("SHOWSKIN", "1");
																		swf_showSkin_420.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_420.addVariable("CLICKURL", "membres.php?p=420");
																		swf_showSkin_420.addVariable("HIDEBORDER", "1");

																		swf_showSkin_420.addParam("menu", "true");
																		swf_showSkin_420.write("div_showSkin_420");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=420">
																			<strong>Raphy_</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				P'tit Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_17461" class="div_showskin" style="width:90px;height:90px;margin: 0; padding: 0; background: #000000"></div>
																		<script type="text/javascript">
																		var swf_showSkin_17461= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "98", "#000000");
																		swf_showSkin_17461.addParam("wmode", "transparent");swf_showSkin_17461.addVariable("ACTION", "11");
																		swf_showSkin_17461.addVariable("SKINID", "98");
																		swf_showSkin_17461.addVariable("SKINCOLOR", "QNNS%2AMI%13LM");
																		swf_showSkin_17461.addVariable("FONDID", "0");
																		swf_showSkin_17461.addVariable("SHOWSKIN", "1");
																		swf_showSkin_17461.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_17461.addVariable("CLICKURL", "membres.php?p=17461");
																		swf_showSkin_17461.addVariable("HIDEBORDER", "1");

																		swf_showSkin_17461.addParam("menu", "true");
																		swf_showSkin_17461.write("div_showSkin_17461");
																		</script>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=17461">
																			<strong>conio</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				P'tit Modo <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div>															</center>
														</div>
																												<table class="td0" style="width:100%;border-spacing:0;background:#fff6bc">
															<tbody>
																<tr>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_tl.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td class="boxjaune_brd_t" style="height:10px;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_tr.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																</tr>
																<tr>
																	<td class="boxjaune_brd_l" style="width:10px"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td>
																		<span style="color:#000000;"><strong style="font-size:13px;">Les Animateurs</strong></span>
																	</td>
																	<td class="boxjaune_brd_r" style="width:10px"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																</tr>
																<tr>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_dl.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td class="boxjaune_brd_b" style="height:10px;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_dr.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" width="10" height="10"></td>
																</tr>
															</tbody>
														</table><br>
														
														<div style="text-align:center">
															<center>
																<div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_40776" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background: #FFFFFF"></div>
																		<script type="text/javascript">
																		var swf_showSkin_40776= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "135", "#FFFFFF");
																		swf_showSkin_40776.addParam("wmode", "transparent");swf_showSkin_40776.addVariable("ACTION", "0");
																		swf_showSkin_40776.addVariable("SKINID", "135");
																		swf_showSkin_40776.addVariable("SKINCOLOR", "1%01%3CB%3B1%3C%3C11");
																		swf_showSkin_40776.addVariable("FONDID", "0");
																		swf_showSkin_40776.addVariable("SHOWSKIN", "1");
																		swf_showSkin_40776.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_40776.addVariable("CLICKURL", "membres.php?p=40776");
																		swf_showSkin_40776.addVariable("HIDEBORDER", "1");

																		swf_showSkin_40776.addParam("menu", "true");
																		swf_showSkin_40776.write("div_showSkin_40776");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=40776">
																			<strong>Certitude</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																			Animateur <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_40989" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=419420&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_40989= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#f08fff");
																		swf_showSkin_40989.addParam("wmode", "transparent");swf_showSkin_40989.addVariable("ACTION", "10");
																		swf_showSkin_40989.addVariable("SKINID", "");
																		swf_showSkin_40989.addVariable("SKINCOLOR", "");
																		swf_showSkin_40989.addVariable("FONDID", "0");
																		swf_showSkin_40989.addVariable("SHOWSKIN", "0");
																		swf_showSkin_40989.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_40989.addVariable("CLICKURL", "membres.php?p=40989");
																		swf_showSkin_40989.addVariable("HIDEBORDER", "1");

																		swf_showSkin_40989.addParam("menu", "true");
																		swf_showSkin_40989.write("div_showSkin_40989");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=40989">
																			<strong>Disney</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																			Animateur <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_41103" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=66834&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_41103= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_41103.addParam("wmode", "transparent");swf_showSkin_41103.addVariable("ACTION", "11");
																		swf_showSkin_41103.addVariable("SKINID", "");
																		swf_showSkin_41103.addVariable("SKINCOLOR", "");
																		swf_showSkin_41103.addVariable("FONDID", "0");
																		swf_showSkin_41103.addVariable("SHOWSKIN", "0");
																		swf_showSkin_41103.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_41103.addVariable("CLICKURL", "membres.php?p=41103");
																		swf_showSkin_41103.addVariable("HIDEBORDER", "1");

																		swf_showSkin_41103.addParam("menu", "true");
																		swf_showSkin_41103.write("div_showSkin_41103");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=41103">
																			<strong>Eliza</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																			Animateur <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_41299" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background: #FFFFFF"></div>
																		<script type="text/javascript">
																		var swf_showSkin_41299= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "239", "#FFFFFF");
																		swf_showSkin_41299.addParam("wmode", "transparent");swf_showSkin_41299.addVariable("ACTION", "0");
																		swf_showSkin_41299.addVariable("SKINID", "239");
																		swf_showSkin_41299.addVariable("SKINCOLOR", "%28G%01%28%01%28%28%3C%01G");
																		swf_showSkin_41299.addVariable("FONDID", "0");
																		swf_showSkin_41299.addVariable("SHOWSKIN", "1");
																		swf_showSkin_41299.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_41299.addVariable("CLICKURL", "membres.php?p=41299");
																		swf_showSkin_41299.addVariable("HIDEBORDER", "1");

																		swf_showSkin_41299.addParam("menu", "true");
																		swf_showSkin_41299.write("div_showSkin_41299");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=41299">
																			<strong>Horacio</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																			Animateur <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_38804" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=183715&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_38804= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FEFE14");
																		swf_showSkin_38804.addParam("wmode", "transparent");swf_showSkin_38804.addVariable("ACTION", "51");
																		swf_showSkin_38804.addVariable("SKINID", "");
																		swf_showSkin_38804.addVariable("SKINCOLOR", "");
																		swf_showSkin_38804.addVariable("FONDID", "0");
																		swf_showSkin_38804.addVariable("SHOWSKIN", "0");
																		swf_showSkin_38804.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_38804.addVariable("CLICKURL", "membres.php?p=38804");
																		swf_showSkin_38804.addVariable("HIDEBORDER", "1");

																		swf_showSkin_38804.addParam("menu", "true");
																		swf_showSkin_38804.write("div_showSkin_38804");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=38804">
																			<strong>Lois</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																			Animateur <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_38113" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=99022&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_38113= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_38113.addParam("wmode", "transparent");swf_showSkin_38113.addVariable("ACTION", "0");
																		swf_showSkin_38113.addVariable("SKINID", "");
																		swf_showSkin_38113.addVariable("SKINCOLOR", "");
																		swf_showSkin_38113.addVariable("FONDID", "0");
																		swf_showSkin_38113.addVariable("SHOWSKIN", "0");
																		swf_showSkin_38113.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_38113.addVariable("CLICKURL", "membres.php?p=38113");
																		swf_showSkin_38113.addVariable("HIDEBORDER", "1");

																		swf_showSkin_38113.addParam("menu", "true");
																		swf_showSkin_38113.write("div_showSkin_38113");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=38113">
																			<strong>Ryujin</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																			Animateur <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_27411" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=659194&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_27411= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_27411.addParam("wmode", "transparent");swf_showSkin_27411.addVariable("ACTION", "0");
																		swf_showSkin_27411.addVariable("SKINID", "");
																		swf_showSkin_27411.addVariable("SKINCOLOR", "");
																		swf_showSkin_27411.addVariable("FONDID", "0");
																		swf_showSkin_27411.addVariable("SHOWSKIN", "0");
																		swf_showSkin_27411.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_27411.addVariable("CLICKURL", "membres.php?p=27411");
																		swf_showSkin_27411.addVariable("HIDEBORDER", "1");

																		swf_showSkin_27411.addParam("menu", "true");
																		swf_showSkin_27411.write("div_showSkin_27411");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=27411">
																			<strong>Cassette</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																			P'tit Anim <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_422" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=968984&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_422= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "574", "#FFFFFF");
																		swf_showSkin_422.addParam("wmode", "transparent");swf_showSkin_422.addVariable("ACTION", "2");
																		swf_showSkin_422.addVariable("SKINID", "574");
																		swf_showSkin_422.addVariable("SKINCOLOR", "%13%01Y97M%0295%3B");
																		swf_showSkin_422.addVariable("FONDID", "0");
																		swf_showSkin_422.addVariable("SHOWSKIN", "1");
																		swf_showSkin_422.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_422.addVariable("CLICKURL", "membres.php?p=422");
																		swf_showSkin_422.addVariable("HIDEBORDER", "1");

																		swf_showSkin_422.addParam("menu", "true");
																		swf_showSkin_422.write("div_showSkin_422");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=422">
																			<strong>Dierfetje</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																			P'tit Anim <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Chat <br>
																				<img alt="" src="/data/Profil/p_con_0.gif"> Forum
																			</div>
																		</a>
																	</div>															</center>
														</div>
																												<br><br>
														<a id="list_equipe"></a>
														<div id="DIVG_BBL_2"></div>
														<script src="/assets/js/swf/goodies_title.js"></script>
														<script>
														goodies("DIVG_BBL_2", "L'EQUIPE BLABLALAND CO");
														</script>
														<br>
														<table class="td0" style="background:#FFF6BC;border-spacing:0;width:100%">
															<tbody>
																<tr>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_tl.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																	<td class="boxjaune_brd_t" style="height:10px;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_tr.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																</tr>
																<tr>
																	<td class="boxjaune_brd_l" style="width:10px"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																	<td> Tous les membres que tu vois ci-dessous travaillent sur Blablaland.co.</td>
																	<td class="boxjaune_brd_r" style="width:10px"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px;"></td>
																</tr>
																<tr>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_dl.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px"></td>
																	<td class="boxjaune_brd_b" style="height:10px;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px"></td>
																	<td style="width:10px;height:10px;background:url(/data/left/jaune_dr.gif);background-size:cover;;line-height:0"><img src="/data/left/spacer.gif" alt style="width:10px;height:10px"></td>
																</tr>
															</tbody>
														</table>
														<br>
														<div style="text-align:center">
															<center>
																<div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_1" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background: #FFFFFF"></div>
																		<script type="text/javascript">
																		var swf_showSkin_1= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "392", "#FFFFFF");
																		swf_showSkin_1.addParam("wmode", "transparent");swf_showSkin_1.addVariable("ACTION", "0");
																		swf_showSkin_1.addVariable("SKINID", "392");
																		swf_showSkin_1.addVariable("SKINCOLOR", "QG%0C%01%01%02%01%01%01I");
																		swf_showSkin_1.addVariable("FONDID", "0");
																		swf_showSkin_1.addVariable("SHOWSKIN", "1");
																		swf_showSkin_1.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_1.addVariable("CLICKURL", "membres.php?p=1");
																		swf_showSkin_1.addVariable("HIDEBORDER", "1");

																		swf_showSkin_1.addParam("menu", "true");
																		swf_showSkin_1.write("div_showSkin_1");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=1">
																			<strong>Night</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Développeur BBL																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_2" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=173577&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_2= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FEFEFE");
																		swf_showSkin_2.addParam("wmode", "transparent");swf_showSkin_2.addVariable("ACTION", "0");
																		swf_showSkin_2.addVariable("SKINID", "");
																		swf_showSkin_2.addVariable("SKINCOLOR", "");
																		swf_showSkin_2.addVariable("FONDID", "0");
																		swf_showSkin_2.addVariable("SHOWSKIN", "0");
																		swf_showSkin_2.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_2.addVariable("CLICKURL", "membres.php?p=2");
																		swf_showSkin_2.addVariable("HIDEBORDER", "1");

																		swf_showSkin_2.addParam("menu", "true");
																		swf_showSkin_2.write("div_showSkin_2");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=2">
																			<strong>zagicien</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Développeur BBL																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_22" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=932660&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_22= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FFFFFF");
																		swf_showSkin_22.addParam("wmode", "transparent");swf_showSkin_22.addVariable("ACTION", "0");
																		swf_showSkin_22.addVariable("SKINID", "");
																		swf_showSkin_22.addVariable("SKINCOLOR", "");
																		swf_showSkin_22.addVariable("FONDID", "0");
																		swf_showSkin_22.addVariable("SHOWSKIN", "0");
																		swf_showSkin_22.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_22.addVariable("CLICKURL", "membres.php?p=22");
																		swf_showSkin_22.addVariable("HIDEBORDER", "1");

																		swf_showSkin_22.addParam("menu", "true");
																		swf_showSkin_22.write("div_showSkin_22");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=22">
																			<strong>Cosmia</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Resp. Staff																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_38457" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=548230&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_38457= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#FEFEFE");
																		swf_showSkin_38457.addParam("wmode", "transparent");swf_showSkin_38457.addVariable("ACTION", "0");
																		swf_showSkin_38457.addVariable("SKINID", "");
																		swf_showSkin_38457.addVariable("SKINCOLOR", "");
																		swf_showSkin_38457.addVariable("FONDID", "0");
																		swf_showSkin_38457.addVariable("SHOWSKIN", "0");
																		swf_showSkin_38457.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_38457.addVariable("CLICKURL", "membres.php?p=38457");
																		swf_showSkin_38457.addVariable("HIDEBORDER", "1");

																		swf_showSkin_38457.addParam("menu", "true");
																		swf_showSkin_38457.write("div_showSkin_38457");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=38457">
																			<strong>Yasko</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Resp. Staff																			</div>
																		</a>
																	</div><div style="display: inline-block;padding:10px 10px 20px 10px;">
																		<div id="div_showSkin_42695" class="div_showskin" style="display: inline-block; width:90px;height:90px;margin: 0; padding: 0; background-image:url(/scripts/download.php?ID=424340&amp;VIEW=1&amp;NOSTATS=1); background-size:90px;background-size:cover;"></div>
																		<script type="text/javascript">
																		var swf_showSkin_42695= new SWFObject("/outils/elements/viewskin/viewskin.swf", "Skin BBL", "90", "90", "", "#f4efff");
																		swf_showSkin_42695.addParam("wmode", "transparent");swf_showSkin_42695.addVariable("ACTION", "50");
																		swf_showSkin_42695.addVariable("SKINID", "");
																		swf_showSkin_42695.addVariable("SKINCOLOR", "");
																		swf_showSkin_42695.addVariable("FONDID", "0");
																		swf_showSkin_42695.addVariable("SHOWSKIN", "0");
																		swf_showSkin_42695.addVariable("CACHE_VERSION", "406");
																		swf_showSkin_42695.addVariable("CLICKURL", "membres.php?p=42695");
																		swf_showSkin_42695.addVariable("HIDEBORDER", "1");

																		swf_showSkin_42695.addParam("menu", "true");
																		swf_showSkin_42695.write("div_showSkin_42695");
																		</script><br>
																		<a class="fofo_link3_extern" href="/site/membres.php?p=42695">
																			<strong>Poeme</strong><br>
																			<div style="text-align:center;color:#999999;font-size:10px;">
																				Graphiste BBL																			</div>
																		</a>
																	</div>															</center>
														</div>
														<br>
														<div style="text-align:center"><img alt="Blablaland, la communauté du Chat gratuit" src="/data/left/footer_page_communaute.jpg" style="float:left"></div>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table><img src="/data/left/spacer.gif" alt style="width:100%;height:5px;">
		<br> 
	</div>
<div id="BBLOLD_RIGHT" style="float:right;width:250px;text-align:right;">

	
	<div id="bloc_promo" class="new_bloc_droit">
		<div class="header">
			<a href="?site=shop_index.php">EN BOUTIQUE</a>
		</div>
		<div class="content">
			<a href="/site/shop_skin.php?giveme=691" class="gondole_title">Exo Armure FrostWolf</a>
			<div id="gondole_produit">
				<div id="gondole_bandeau" class="new">
					<a href="?site=shop_skin.php?giveme=691">
						<img width="90" src="/data/skins/691.jpg" alt="Exo Armure FrostWolf" title="Exo Armure FrostWolf">
					</a>
				</div>
			</div>
			<span class="bloc_droit_promo_price_final">2100 BBL</span><a href="/site/shop_skin.php?giveme=691" id="buy_promo_link"></a>
		</div>
	</div>

	<div class="new_bloc_droit">
		<div class="header" style="background:url(https://i.imgur.com/sqrtkzb.jpg)">
			<a href="/site/loteries.php">BLABLA'LOTERIE</a>
		</div>
		<div class="content text-center" style="background:#fdd637">
			<table class="td0" style="margin:0 auto;border-spacing: 3px;">
				<tbody>
					<tr>								
							<td style="text-align:center">
								<a class="fofo_link3_extern" href="/site/membres.php?p=36912" title="Voir son Profil"><strong>ApathikQc</strong></a> <br>
								<a class="fofo_link3_extern" href="/site/loteries.php?lid=3" style="color:#F00088;"><strong>300 Blabillons</strong></a><br>
								<span class="box_stitle_gris">Aujourd'hui à 00h00</span>							</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<div id="bloc_forum" class="new_bloc_droit">
		<div class="header">
			<a href="/forum/">FORUM</a>
		</div>
		<div class="content">
		<img alt="" src="/data/left/etoile2.gif"> <a href="/forum/viewtopic.php?pid=24199#p24199" title="La Guerre des Sexes" class="fofo_link_extern">La Guerre des Sexes</a><br><div style="line-height:12px"><span class="fofo_info_extern">Par <a class="fofo_link2_extern" title="Voir le profil de Meridian" href="/site/membres.php?p=42417"><strong>Meridian</strong></a>, dernier post de <a class="fofo_link2_extern" title="Voir le profil de Daisy" href="/site/membres.php?p=37552"><strong>Daisy</strong></a></span></div><img alt="" src="/data/left/spacer.gif" height="5" style="display:block"><br><img alt="" src="/data/left/etoile2.gif"> <a href="/forum/viewtopic.php?pid=24196#p24196" title="À quoi ça te fait penser ?" class="fofo_link_extern">À quoi ça te fait penser ?</a><br><div style="line-height:12px"><span class="fofo_info_extern">Par <a class="fofo_link2_extern" title="Voir le profil de Road" href="/site/membres.php?p=663"><strong>Road</strong></a>, dernier post de <a class="fofo_link2_extern" title="Voir le profil de Meridian" href="/site/membres.php?p=42417"><strong>Meridian</strong></a></span></div><img alt="" src="/data/left/spacer.gif" height="5" style="display:block"><br><img alt="" src="/data/left/etoile2.gif"> <a href="/forum/viewtopic.php?pid=24195#p24195" title="À quoi ça te fait penser ?" class="fofo_link_extern">À quoi ça te fait penser ?</a><br><div style="line-height:12px"><span class="fofo_info_extern">Par <a class="fofo_link2_extern" title="Voir le profil de Meridian" href="/site/membres.php?p=42417"><strong>Meridian</strong></a>, dernier post de <a class="fofo_link2_extern" title="Voir le profil de Meridian" href="/site/membres.php?p=42417"><strong>Meridian</strong></a></span></div><img alt="" src="/data/left/spacer.gif" height="5" style="display:block"><br><img alt="" src="/data/left/etoile2.gif"> <a href="/forum/viewtopic.php?pid=24192#p24192" title="Tu préfères ... ou ... ?" class="fofo_link_extern">Tu préfères ... ou ... ?</a><br><div style="line-height:12px"><span class="fofo_info_extern">Par <a class="fofo_link2_extern" title="Voir le profil de Road" href="/site/membres.php?p=663"><strong>Road</strong></a>, dernier post de <a class="fofo_link2_extern" title="Voir le profil de Deyluge" href="/site/membres.php?p=36788"><strong>Deyluge</strong></a></span></div><img alt="" src="/data/left/spacer.gif" height="5" style="display:block"><br><img alt="" src="/data/left/etoile2.gif"> <a href="/forum/viewtopic.php?pid=24189#p24189" title="[Jeu] De quel film s'agit-il ?" class="fofo_link_extern">[Jeu] De quel film s&#039;agit-il ?</a><br><div style="line-height:12px"><span class="fofo_info_extern">Par <a class="fofo_link2_extern" title="Voir le profil de Appareil" href="/site/membres.php?p=8274"><strong>Appareil</strong></a>, dernier post de <a class="fofo_link2_extern" title="Voir le profil de Appareil" href="/site/membres.php?p=8274"><strong>Appareil</strong></a></span></div><img alt="" src="/data/left/spacer.gif" height="5" style="display:block"><br>		</div>
	</div>
<div id="bloc_discord" class="new_bloc_droit without_content"><a href="https://discord.gg/blablaland" target="_blank"><img alt="" class="header" src="/data/left/discord.jpg" height="57"></a></div>
	
	<div style="clear:both;"></div></div>		</div>
    	<div class="clr" style="height:0px;"></div>
		
	</div>
	<div id="FOOTER">
		<div id="FOOTER_CUT"></div>
		<div id="FOOTER_CONTENT">
			<div id="FOOTER_CONTENT_LEFT">
				<a href="/" title="Blablaland, jeu vid&#x00E9;o en ligne : l&#39;aventure commence ici"><img alt="" src="/data/logo/footer_logo.png" id="FOOTER_LOGO"></a>
				<div style="text-align: center;font-weight: bold;">Projet à but non lucratif</div>
				<div class="clr"></div>
				<div id="FOOTER_MENU">
					<ul>
						<li class="footer_btn_jouer"><a href="/chat/bbl_chat.php" title="Partez &#x00E9; l&#39;aventure !">JOUER</a></li>
						<li class="footer_btn_inscrire"><a href="/site/inscription.php" title="Créer votre personnage, c'est gratuit !">S'INSCRIRE</a></li>
						<li class="footer_btn_main"><a href="/">ACCUEIL</a></li>
						<li class="footer_btn_main"><a href="/site/news.php">LES NEWS</a></li>
						<li class="footer_btn_main"><a href="/forum">FORUMS</a></li>
						<li class="footer_btn_main"><a href="/site/aide.php">AIDE</a></li>
					</ul>
					<ul>
						<li class="footer_btn_main"><a href="/site/blablaland.php">Le Jeu</a></li>
						<li><a href="/site/blablaland.php">Découvrez le jeu</a></li>
						<li><a href="/site/news.php">L'actualité du jeu</a></li>
					</ul>
					<ul>
						<li class="footer_btn_main"><a href="/site/communaute.php">Communaut&#x00E9;</a></li>
						<li><a href="/site/bblartclub.php">BBL Art'Club</a></li>
						<li><a href="/site/fansites.php">Fansites</a></li>
						<li><a href="/site/bd_blabla.php">BD Blabla</a></li>
						<li><a href="/site/annuaire_bbl.php">Annuaires joueurs</a></li>
						<li><a href="/site/forum.php">Forums</a></li>
						<li><a href="#">Invite tes amis</a></li>
					</ul>
					<ul>
						<li class="footer_btn_main"><a href="/site/shop_index.php">Boutique</a></li>
						<li><a href="/site/shop_index.php">Boutique Blabla</a></li>
						<li><a href="/site/blabillons.php">Blabillons</a></li>
						<li><a href="#">Artbook, Porte-cl&#x00E9;s&hellip;</a></li>
					</ul>
					<ul>
						<li class="footer_btn_main"><a href="/site/mini_jeux.php">Mini-Jeux</a></li>
						<li><a href="/site/jeu_donjon.php">Donjon</a></li>
						<li><a href="/site/jeu_manoir.php">Manoir Hanté</a></li>
						<li><a href="/site/jeu_pyramide.php">Huybit III</a></li>
						<li><a href="/site/jeu_bbl_tournament_fury.php">Tournament Fury</a></li>
						<li><a href="/site/jeu_blablataille_navale.php">Blablataille N.</a></li>
						<li><a href="/site/loteries.php">Loteries</a></li>
						<li><a href="/site/jeu_madame_pipi.php">Madame Pipi</a></li>
						<li><a href="/site/wwf_panda.php">WWF Panda</a></li>
					</ul>
					<ul>
						<li class="footer_btn_main"><a href="/site/goodies.php">M&#x00E9;dias</a></li>
						<li><a href="/site/goodies.php">Goodies</a></li>
						<li><a href="/site/bd_blabla.php">BD Blablas</a></li>
					</ul>
					<div class="clr"></div>
					<br style="line-height:12px">					<br style="line-height:12px">
					<br style="line-height:12px">
					<div class="clr"></div>
					<br style="line-height:12px">
				</div>
			</div>
			<div id="FOOTER_CONTENT_RIGHT">
				<a href="#" id="fafafa"><img alt="BLABLALAND.CO" class="footer_logo_n99" src="/data/left/Blablalandlogov2.png" width="45" height="45"></a>
				<p style="font-size: 10.5px;letter-spacing: -1px;">BLABLALAND.CO n'est pas associé ni adhéré par Niveau99
					<br>
				</p><a title="BLABLALAND.CO" class="a_rounded" href="#" style="line-height: 21px">BLABLALAND.CO</a>
				<ul style="margin-top:2px">
					<li><a title="Besoin d'aide ?" href="/site/team_blablaland.php" target="_blank"><strong>ASSISTANCE EN LIGNE</strong></a></li>
					<li style="margin-top:12px"><a href="/site/infos_reglement.php">REGLEMENT DU JEU</a></li>
				</ul>
				<br>
				<br>
				<div style="padding-right: 15px; float: left;"></div>
				<div style="padding-right: 15px; float: left;">
					<div class=" fb_reset fb_reset">
						<div style="top: -10000px; width: 0px; height: 0px; position: absolute;">
							<div></div>
						</div>
						<div style="top: -10000px; width: 0px; height: 0px; position: absolute;">
							<div></div>
						</div>
						<div style="top: -10000px; width: 0px; height: 0px; position: absolute;">
							<div></div>
						</div>
					</div>
					<br>
					<br>
					<br>
					<br>
				</div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="clr" style="height:30px"></div>
	</div>	<script type="text/javascript">
		initTopMenu();
	</script>
<script>(function(){var js = "window['__CF$cv$params']={r:'7c4f638dcb5e00a2',m:'qajxebG0kohzxdnyawOcFMCM_jbLy5fZ8z0UQTmPrro-1683692418-0-AewwOCW6FJo3SyDoZ49lZMSV7jZcAxBraY3yO2PUSK/d',u:'/cdn-cgi/challenge-platform/h/g'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='/cdn-cgi/challenge-platform/scripts/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body></html>