var CHAT_PAGE = false;

function nb_setToNb(_nb) {
	_nb = Math.round(_nb);
	if (_nb < 0 || isNaN(_nb)) { _nb = 0; }
	return _nb;
}

function nb_format_std(_nb) {
	_nb = nb_setToNb(_nb);
	var _nbtxt = _nb+"";
	var tab = _nbtxt.split('');
	var cmpt = 1;
	var ret = "";
	for (var i=(tab.length-1); i>=0; i--) {
		ret = tab[i]+""+ret;
		if (cmpt%3 == 0 && i>0) { ret = " "+ret; }
		cmpt++;
	}
	return ret;
}


/* ************************************************************ */

// BBLBONUS MENU POPUP

function compteurBBLBONUS(_init) {
	BBLBONUS_CMPT = _init;
	
	var s = Math.floor(BBLBONUS_CMPT % 60);
	var m = Math.floor(BBLBONUS_CMPT / 60);
	$("#bblbonus_chrono").html(''+m+' min et '+s+' sec');
	$("#bblbonus_chrono2").html(''+m+' min et '+s+' sec');
	//$("#bblbonus_chrono").html(BBLBONUS_CMPT);
	
	var t=setTimeout(function() {
		BBLBONUS_CMPT--;
		if (BBLBONUS_CMPT > 0) {			
			compteurBBLBONUS(BBLBONUS_CMPT);
		} else {
			$("#POPUP_BONUSBBL").fadeOut(400);
		}
	}, 1002);
}

//secCounter = Math.floor(counter % 60);
//minCounter = Math.floor(counter / 60);
	

/* ************************************************************ */


function bblinfos_setNBC(_nb) {
	$("#BBLINFOS_NBC").html(nb_format_std(_nb));
}

function bblinfos_setBBL(_nb) {

	_nb = nb_format_std(_nb);
	
	$("#BBLINFOS_BBL").fadeOut(150, function() {
		$("a #BBLINFOS_BBL").attr("title", "Tu as "+_nb+" Blabillons");
		$("#BBLINFOS_BBL").html("<img src=\"/data/Profil/picto_bbl.png\" /> "+_nb+" <span>BBL</span>");
		$("#BBLINFOS_BBL").fadeIn(150);
	});
}

function bblinfos_setXP(_nb) {

	_nb = nb_format_std(_nb);
	
	//9DE500
	//f50084
	//009edf
	//$("#BBLINFOS_XP").css("background-color", "#9DE500");
	//$("#BBLINFOS_XP").css("color", "#FFFFFF");
		
	$("#BBLINFOS_XP").fadeOut(150, function() {
		$("a #BBLINFOS_XP").attr("title", "Tu as "+_nb+" points d'XP");
		$("#BBLINFOS_XP").html("<img src=\"/data/Profil/picto_xp.png\" /> "+_nb+" <span>XP</span>");
		$("#BBLINFOS_XP").fadeIn(150);
		//$("#BBLINFOS_XP").css("background-color", "#FFFFFF");
		//$("#BBLINFOS_XP").css("color", "#01B4FF");
		
		/*
		$("#BBLINFOS_XP").css("background-color", "#9DE500").css("color", "#FFFFFF");
		$("#BBLINFOS_XP").html("<img src=\"/site/images/_template/picto_xp.png\" /> +1");
		
		$("#BBLINFOS_XP").fadeIn(600, function() {
			$("#BBLINFOS_XP").css("background-color", "#FFFFFF").css("color", "#01B4FF");	
			$("#BBLINFOS_XP").html("<img src=\"/data/Profil/picto_xp.png\" /> "+_nb+" <span>XP</span>");
		});
		*/
		
		//$("#BBLINFOS_XP").css("background-color", "#FFFFFF");
		//$("#BBLINFOS_XP").css("color", "#01B4FF");
	});
	
}

function bblinfos_setMessages_up(_up) {
	
	_up = Math.round(_up);
	if (isNaN(_up)) { _up = 0; }
	
	if (_up != 0) {
		bblinfos_nbmess_new += _up;
		bblinfos_nbmess_tot += _up;
		bblinfos_setMessages(bblinfos_nbmess_new,bblinfos_nbmess_tot);
	}
	
}

function bblinfos_setMessages(_nb_new, _nb_tot) {
	
	_nb_new = nb_setToNb(_nb_new);
	_nb_tot = nb_setToNb(_nb_tot);
	
	var newS = (_nb_new > 1) ? "s" : "";
	var newX = (_nb_new > 1) ? "x" : "";
	var mesS = (_nb_tot > 1) ? "s" : "";
	
	_nb_new = nb_format_std(_nb_new);
	_nb_tot = nb_format_std(_nb_tot);
	
	$("#BBLINFOS_MESS").fadeOut(150, function() {
		$("a #BBLINFOS_MESS").attr("title", "Tu as "+_nb_new+" courrier"+newS+" non lu"+newS+" sur "+_nb_tot+"");
		$("#BBLINFOS_MESS").html("<img src=\"/data/Profil/picto_messages.png\" /> "+_nb_new+"<span> nouveau"+newX+"</span>");
		$("#BBLINFOS_MESS").fadeIn(150);
	});
}

function bblinfos_setAmis(_nb_co,_nb_tot,_nb_invit) {

	_nb_co = nb_setToNb(_nb_co);
	_nb_tot = nb_setToNb(_nb_tot);
	_nb_invit = nb_setToNb(_nb_invit);
	
	var amiS = (_nb_co > 1) ? "s" : "";
	var invitS = (_nb_invit > 1) ? "s" : "";
	
	_nb_co = nb_format_std(_nb_co);
	_nb_tot = nb_format_std(_nb_tot);
	_nb_invit = nb_format_std(_nb_invit);
	
	$("#BBLINFOS_AMIS").fadeOut(150, function() {
		$("a #BBLINFOS_AMIS").attr("title", "Tu as "+_nb_co+" ami"+amiS+" en jeu sur "+_nb_tot+", et "+_nb_invit+" invitation"+invitS+""); 
		//, et "+_nb_invit+" invitation"+invitS+"
		$("#BBLINFOS_AMIS").html("<img src=\"/data/Profil/picto_amis.png\" /> "+_nb_co+"<span>/"+_nb_tot+" Amis (</span>"+_nb_invit+"<span>)</span>");
		$("#BBLINFOS_AMIS").fadeIn(150);
	});
}





// PLACER LE MENU DU HAUT EN PERMANENCE VISIBLE EN HAUT DE LA PAGE

var positionElementInPage = 0;
function initTopMenu(){
	if( !CHAT_PAGE ){
		if ( $( "#MENU" ).length ) {
			positionElementInPage = $('#MENU').offset().top;
			$(window).scroll(function() {computeTopMenu()});
			computeTopMenu();
		}
	}
}

function computeTopMenu(){
	if ($(window).scrollTop() >= positionElementInPage) {
		// fixed
		$('#MENU').addClass("floatable");
		$('#HEADER').addClass("replaceMenu");
	} else {
		// relative
		$('#MENU').removeClass("floatable");
		$('#HEADER').removeClass("replaceMenu");
	}
}

