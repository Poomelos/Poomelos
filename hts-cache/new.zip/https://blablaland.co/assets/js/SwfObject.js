
swfobject = {}
swfobject.embedSWF = function (){
		var e = 0;
		b = document.createElement("object"), b.type = "application/x-shockwave-flash", b.data = arguments[e++];
		var a = arguments[e++];
		var div, DIV = document.getElementById(a).getElementsByTagName("div");
		for (div in DIV)
			if (div = DIV[div])
				if (div && div.getAttribute && div.getAttribute("id") && div.getAttribute("id").substr(0,7)=="swf2js_")
					swf2js.dispose(div.getAttribute("id").substr(7));
		b.width = arguments[e++], b.height = arguments[e++];
		e++;
		var t = arguments[e++],
			F = arguments[e++];
		F && Object.keys(F).length && ((d = document.createElement("param")).name = "flashvars", d.value = Object.keys(F).map(function(e){ return e + "=" + F[e] }).join("&"), b.appendChild(d));
		for (var c, f, l, s, d = arguments[+e], i = Object.keys(d); i.length;)(c = document.createElement("param")).name = i.pop(), c.value = d[c.name], b.appendChild(c);
		try {
			f = new ActiveXObject("ShockwaveFlash.ShockwaveFlash")
		} catch (u) {
			f = navigator.mimeTypes["application/x-shockwave-flash"]
		}
		if (f) document.getElementById(a).innerHTML = "";
		if (f) return document.getElementById(a).appendChild(b);
			if (t && document.createElement("canvas").getContext("webgl")) return void("undefined" != typeof swf2js ? (window.cemx++<15) && swf2js.load(b.data, {
				tagId: a,
				bgcolor: "0",
				FlashVars: F
			}) : ((s = document.createElement("script")).src = "//blablaland.co/assets/js/swf2js.js", s.onload = function() {
				(window.cemx++<15) && swf2js.load(b.data, {
					tagId: a,
					bgcolor: "0",
					FlashVars: F
				})
			}, document.getElementsByTagName("head")[0].appendChild(s)));
			F && (9 in arguments && (document.getElementById(arguments[9]).style.display = "block"))
};

cemx = 0
SWFObject = function () {
	this.flash = {};
	this.dom = document.createElement("embed");
	this.arguments = arguments;
	this.addVariable = function(a, b) {
		this.flash[a] = b;
	}, this.addParam = function(a, b) {
		this.dom.setAttribute(a, b);
	}, this.write = function(a) {
		var b = document.getElementById(a);
		var div, DIV = document.getElementById(a).getElementsByTagName("div");
		for (div in DIV)
			if (div = DIV[div])
				if (div && div.getAttribute && div.getAttribute("id") && div.getAttribute("id").substr(0,7)=="swf2js_")
					swf2js.dispose(div.getAttribute("id").substr(7));
		var d = 0,
			g = this.dom.src = this.arguments[d++],
			h = this.flash;
		this.arguments[d++];
		this.dom.width = this.arguments[d++];
		this.dom.height = this.arguments[d++];
		var i = this.arguments[d++];
		this.dom.type = "application/x-shockwave-flash";
		var j, d = this.arguments[+d];
		d && this.dom.setAttribute("bgcolor", d);
		Object.keys(this.flash).length && this.dom.setAttribute("flashvars", Object.keys(this.flash).map(function(a){return a + "=" + h[a]}).join("&"));
		try {
			j = new ActiveXObject("ShockwaveFlash.ShockwaveFlash");
		} catch (a) {
			j = navigator.mimeTypes["application/x-shockwave-flash"];
		}
		j || "2" != i || (document.getElementById(a).style.backgroundImage = "url('/assets/img/bskins/" + this.flash.SKINID + ".png')", i = "");
		if (!j && !i && "CLICKURL" in this.flash) {
			var l, k = b.parentNode;
			(l = document.createElement("a")).href = this.flash.CLICKURL;
			k.replaceChild(l, b);
			l.appendChild(b)
		}
		j ? b.appendChild(this.dom) : i && document.createElement("canvas").getContext("webgl") ? "undefined" == typeof swf2js ? ((i = document.createElement("script")).src = "//blablaland.co/assets/js/swf2js.js", i.onload = function() {
			15 > cemx++ && (b.innerHTML = "", swf2js.load(g, {
				tagId: a,
				bgcolor: "0",
				FlashVars: h
			}))
		}, document.getElementsByTagName("head")[0].appendChild(i)) : 15 > cemx++ && (document.getElementById(a).innerHTML = "", swf2js.load(g, {
			tagId: a,
			bgcolor: "0",
			FlashVars: h
		})) : 6 in this.arguments ? b.innerHTML += this.arguments[6] : ""
	}
};

function jaune(a){
document.write('<table class="td0" style="background:#FFF6BC;border-spacing:0;width:100%"> <tbody> <tr> <td style="line-height:0;height:10px;width:10px;background:url(/data/left/jaune_tl.gif)"> <img height="10" src="/data/left/spacer.gif" width="10"> </td> <td class="boxjaune_brd_t" style="line-height:0;height:10px"> <img height="10" src="/data/left/spacer.gif" width="10"> </td> <td style="line-height:0;height:10px;width:10px;background:url(/data/left/jaune_tr.gif)"> <img height="10" src="/data/left/spacer.gif" width="10"> </td> </tr> <tr> <td class="boxjaune_brd_l" style="width:10px"> <img height="10" src="/data/left/spacer.gif" width="10"> </td> <td>'+a+'</td> <td class="boxjaune_brd_r" style="width:10px"><img src="/data/left/spacer.gif" alt="" style="width:10px;height:10px;"></td></tr> <tr> <td style="line-height:0;height:10px;width:10px;background:url(/data/left/jaune_dl.gif)"> <img height="10" src="/data/left/spacer.gif" width="10"> </td> <td class="boxjaune_brd_b" style="line-height:0;height:10px"> <img height="10" src="/data/left/spacer.gif" width="10"> </td> <td style="line-height:0;height:10px;width:10px;background:url(/data/left/jaune_dr.gif)"> <img height="10" src="/data/left/spacer.gif" width="10"> </td> </tr> </tbody> </table>')
}
function talk(a){
document.write('<table class="td0" style="border-spacing:0;width:100%"><tbody><tr><td style="width:20px;height:10px;line-height:0"><img src="/data/left/TLA.gif" alt="" style="width:20px;height:10px"></td><td style="width:9px;height:10px;line-height:0"><img src="/data/left/TLB.gif" alt="" style="width:9px;height:10px"></td><td style="height:10px;background:url(/data/left/TM.gif);line-height:0"><img src="/data/left/spacer.gif" alt="" style="width:100%;height:10px"></td><td style="width:15px;height:10px;line-height:0"><img src="/data/left/TR.gif" alt="" style="width:15px;height:10px"></td></tr><tr><td style="vertical-align:top;width:20px;background:url(/data/left/MLA.gif)"><img src="/data/left/spacer.gif" alt="" width="20" height="40" style="float:left"><img src="/data/left/talk.gif" alt="" style="width:20px;height:25px"></td><td style="background:#FFFFFF;width:9px">&nbsp;</td><td style="text-align:left;background:#FFFFFF;vertical-align:to">'+a+'</td><td style="width:15px;background:url(/data/left/MR.gif)">&nbsp;</td></tr><tr><td style="height:15px;width:20px;line-height:0"><img src="/data/left/BLA.gif" alt="" style="width:20px;height:15px"></td><td style="height:15px;width:9px;line-height:0"><img src="/data/left/BLB.gif" alt="" style="width:9px;height:15px"></td><td style="height:15px;line-height:0;background:url(/data/left/BM.gif)"><img src="/data/left/spacer.gif" alt="" style="width:100%;height:15px"></td><td style="height:15px;width:15px;line-height:0"><img src="/data/left/BR.gif" alt="" style="width:15px;height:15px"></td></tr></tbody></table>');
}
function box(a){
document.write('<table class="td0" style="border-spacing:0;width:100%"><tbody><tr><td style="line-height:0;height:10px;width:20px"><img alt="" src="/data/left/TLA.gif" width="20" height="10"></td><td style="line-height:0;height:10px;width:9px"><img alt="" src="/data/left/TLB.gif" width="9" height="10"></td><td style="line-height:0;height:10px;background:url(/data/left/TM.gif)"><img alt="" src="/data/left/spacer.gif" width="100%" height="10"></td><td style="line-height:0;height:10px;width:15px"><img alt="" src="/data/left/TR.gif" width="15px" height="10"></td></tr><tr><td style="vertical-align:top;width:20px;background:url(/data/left/MLA.gif)"></td><td style="background:#FFFFFF;width:9px">&nbsp;</td><td style="text-align:left;background:#FFFFFF;vertical-align:top">'+a+'</td><td style="line-height:0;width:15px;background:url(/data/left/MR.gif)">&nbsp;</td></tr><tr><td style="line-height:0;height:15px;width:20px"><img alt="" src="/data/left/BLA.gif" width="20" height="15"></td><td style="line-height:0;height:15px;width:9px"><img alt="" src="/data/left/BLB.gif" width="9" height="15"></td><td style="line-height:0;height:15px;background:url(/data/left/BM.gif)"><img alt="" src="/data/left/spacer.gif" width="100%" height="15"></td><td style="line-height:0;height:15px;width:15px"><img alt="" src="/data/left/BR.gif" width="15" height="15"></td></tr></tbody></table>')
}
function rouge(a){
document.write('<table class="td0" style="background:#FFBCBC;border-spacing:0;width:100%"><tbody><tr><td style="line-height:0;width:10px;height:10px;background:url(/data/left/jaune_tl.gif)"><img alt="" src="/data/left/spacer.gif" width="10" height="10"></td><td class="boxjaune_brd_t" style="line-height:0;height:10px"><img alt="" src="/data/left/spacer.gif" width="10" height="10"></td><td style="line-height:0;background:url(/data/left/jaune_tr.gif);width:10px;height:10px"><img alt="" src="/data/left/spacer.gif" width="10" height="10"></td></tr><tr><td class="boxjaune_brd_l" style="width:10px"><img alt="" src="/data/left/spacer.gif" width="10" height="10"></td><td>'+a+'</td><td class="boxjaune_brd_r" style="width:10px"><img alt="" src="/data/left/spacer.gif" width="10" height="10"></td></tr><tr><td style="line-height:0;width:10px;height:10px;background:url(/data/left/jaune_dl.gif)"><img alt="" src="/data/left/spacer.gif" width="10" height="10"></td><td class="boxjaune_brd_b" style="line-height:0;height:10px"><img alt="" src="/data/left/spacer.gif" width="10" height="10"></td><td style="line-height:0;width:10px;height:10px;background:url(/data/left/jaune_dr.gif)"><img alt="" src="/data/left/spacer.gif" width="10" height="10"></td></tr></tbody></table>')
}
