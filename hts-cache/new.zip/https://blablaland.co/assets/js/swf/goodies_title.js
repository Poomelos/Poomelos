function goodies(t, o, i) {
	if (!window.LOADED_goodies) {
		if (!window.document.documentMode) return l = new FontFace("goodies_title", 'url(/assets/css/goodies_title.woff)format("woff")'), l.load().then(function(e) {
			document.fonts.add(e), LOADED_goodies = !0, goodies(t, o, i)
		});
		LOADED_goodies = !0, document.write("<style>@font-face {font-family: 'goodies_title';src: url('/assets/css/goodies_title.woff') format('woff');}</style>")
	}
	var e, s, n;
	try {
		e = new ActiveXObject("ShockwaveFlash.ShockwaveFlash")
	} catch (s) {
		e = navigator.mimeTypes["application/x-shockwave-flash"]
	}
	e ? (s = window[t], (n = document.createElement("embed")).height = "23", n.width = "100%", n.src = "/assets/swf/goodies_title.swf", n.type = "application/x-shockwave-flash", n.setAttribute("quality", "high"), n.setAttribute("wmode", "transparent"), n.setAttribute("flashvars", "get_title=" + o + (i ? "&get_url=" + i : "")), s.appendChild(n)) : (window[t].style.background = "#dff0b2", window[t].style.width = "100%", window[t].style.fontSize = "20.1px", window[t].style.cursor = "default", window[t].style["-ms-user-select"] = "none", window[t].style.position = "relative", window[t].style.overflow = "hidden", window[t].style.height = "23px", window[t].style.fontFamily = "goodies_title", (n = document.createElement("img")).alt = "", n.src = "/assets/img/swf/1.png", n.style.height = "23px", n.style["margin-left"] = "5px", n.style["pointer-events"] = "none", window[t].appendChild(n), (n = document.createElement("a")).style["user-select"] = "none", n.style.color = "#95cc00", i && (n.href = i), n.innerText = o, n.style.margin = "0 0 0 7px", n.style["vertical-align"] = "top", n.style["line-height"] = "21px", n.style["text-decoration"] = "none", window[t].appendChild(n), (n = document.createElement("img")).alt = "", n.style.margin = "0 0 0 7px", n.style.position = "absolute", n.src = "/assets/img/swf/2.png", n.style.height = "23px", n.style["pointer-events"] = "none", window[t].appendChild(n))
}