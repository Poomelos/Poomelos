var FlashPlayer, a, b, star;

"FontFace" in window ? 
new FontFace("big_title", 'url("/assets/css/big_title.woff")format("woff"),url("/assets/css/big_title.ttf")format("truetype")').load().then(

function(t) {
	document.fonts.add(t)
}

) : document.write("<style>@font-face {font-family: 'big_title';src: url('/assets/css/big_title.woff') format('woff');}</style>");

try {
	FlashPlayer = new ActiveXObject("ShockwaveFlash.ShockwaveFlash")
} catch (t) {
	FlashPlayer = navigator.mimeTypes["application/x-shockwave-flash"]
}
FlashPlayer ? ((b = document.createElement("embed")).height = "34", b.width = "100%", b.src = "/assets/swf/big_title.swf", b.type = "application/x-shockwave-flash", b.setAttribute("quality", "high"), b.setAttribute("wmode", "transparent"), b.setAttribute("flashvars", "get_title=" + decodeURIComponent(document.scripts[document.scripts.length - 1].src.split("#")[1])), DIVP_BBL_1.appendChild(b)) : (DIVP_BBL_1.style.width = "100%", DIVP_BBL_1.style.paddingLeft = "2px", DIVP_BBL_1.style.fontSize = "34px", DIVP_BBL_1.style["user-select"] = "none", DIVP_BBL_1.style.height = "34px", DIVP_BBL_1.style.verticalAlign = "top", DIVP_BBL_1.style.cursor = "default", DIVP_BBL_1.style["-ms-user-select"] = "none", DIVP_BBL_1.style.color = "#bc6bd6", DIVP_BBL_1.style.fontFamily = "big_title", DIVP_BBL_1.innerText = decodeURIComponent(document.scripts[document.scripts.length - 1].src.split("#")[1]), (star = document.createElement("img")).src = "/assets/img/swf/0.png", star.alt = "", star.style["pointer-events"] = "none", star.style.height = "32px", star.style.marginLeft = "12px", star.style.marginTop = "-2px", star.style.position = "absolute", DIVP_BBL_1.appendChild(star));